# AerieCura — Flatsome child theme

Boilerplate child theme dat samen met het bijgevoegde prototype (`AerieCura Website.html`) en de twee handoff-documenten (`WORDPRESS-HANDOFF.md`, `FLATSOME-MAPPING.md`) een ontwikkelaar of Claude Code in staat stelt de definitieve site te bouwen.

## Wat hier in zit

```
flatsome-aeriecura/
├── style.css             ← child theme header
├── functions.php         ← enqueue, includes, theme supports
├── assets/
│   └── css/
│       ├── aeriecura.css ← layout + componenten (uit prototype)
│       └── tokens.css    ← kleuren, typografie, spacing
├── inc/
│   ├── cpt-productcategorie.php   ← CPT registratie
│   ├── acf-fields.php             ← ACF field groups in code
│   ├── login-button.php           ← Inloggen-link met plugin-filters
│   ├── shortcodes.php             ← [aeriecura_hero], [aeriecura_categories], …
│   └── icons.php                  ← inline SVG helper
├── parts/             ← LEEG — wordt door Claude Code aangevuld
└── templates/         ← LEEG — wordt door Claude Code aangevuld
```

## Volgende stappen voor Claude Code

1. Lees `../WORDPRESS-HANDOFF.md` — algemene architectuur
2. Lees `../FLATSOME-MAPPING.md` — block-voor-block instructies
3. Vul `parts/` met de PHP partials genoemd in WORDPRESS-HANDOFF sectie 1
4. Voeg de Lucide SVG iconen toe in `assets/icons/` (zelfde namen als in `components.jsx` van het prototype)
5. Bouw de pagina's volgens de mapping (UX Builder + shortcodes)

## Snelle installatie

1. Zip deze map: `zip -r flatsome-aeriecura.zip flatsome-aeriecura/`
2. WP-admin → Uiterlijk → Thema's → Nieuw → Uploaden
3. Activeer ná Flatsome
4. ACF Pro installeren als dat nog niet gebeurd is
5. Permalink-instellingen opnieuw opslaan (anders werkt CPT slug niet)
