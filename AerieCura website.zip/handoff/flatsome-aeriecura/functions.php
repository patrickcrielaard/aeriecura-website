<?php
/**
 * Theme functions — Flatsome AerieCura child theme.
 *
 * Boilerplate, klaar om door Claude Code te worden uitgebreid.
 *
 * @package aeriecura
 */

defined( 'ABSPATH' ) || exit;

define( 'AERIECURA_VERSION', '1.0.0' );
define( 'AERIECURA_PATH', get_stylesheet_directory() );
define( 'AERIECURA_URL',  get_stylesheet_directory_uri() );

/* ----------------------------------------------------------------------------
 * 1. Enqueue parent + child + tokens
 * ------------------------------------------------------------------------- */
add_action( 'wp_enqueue_scripts', function () {
    // Parent (Flatsome) styles
    wp_enqueue_style( 'flatsome-style', get_template_directory_uri() . '/style.css' );

    // Design tokens — must load before main stylesheet
    wp_enqueue_style(
        'aeriecura-tokens',
        AERIECURA_URL . '/assets/css/tokens.css',
        [],
        AERIECURA_VERSION
    );

    // Main AerieCura stylesheet
    wp_enqueue_style(
        'aeriecura',
        AERIECURA_URL . '/assets/css/aeriecura.css',
        [ 'flatsome-main', 'aeriecura-tokens' ],
        AERIECURA_VERSION
    );
}, 100 );

/* ----------------------------------------------------------------------------
 * 2. Includes
 * ------------------------------------------------------------------------- */
require_once AERIECURA_PATH . '/inc/cpt-productcategorie.php';
require_once AERIECURA_PATH . '/inc/acf-fields.php';
require_once AERIECURA_PATH . '/inc/login-button.php';
require_once AERIECURA_PATH . '/inc/shortcodes.php';
require_once AERIECURA_PATH . '/inc/icons.php';

/* ----------------------------------------------------------------------------
 * 3. ACF Options page
 * ------------------------------------------------------------------------- */
add_action( 'acf/init', function () {
    if ( function_exists( 'acf_add_options_page' ) ) {
        acf_add_options_page( [
            'page_title' => 'AerieCura instellingen',
            'menu_title' => 'AerieCura',
            'menu_slug'  => 'aeriecura-options',
            'capability' => 'edit_posts',
            'icon_url'   => 'dashicons-heart',
            'position'   => 30,
        ] );
    }
} );

/* ----------------------------------------------------------------------------
 * 4. Theme supports
 * ------------------------------------------------------------------------- */
add_action( 'after_setup_theme', function () {
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'html5', [ 'search-form', 'gallery', 'caption' ] );

    register_nav_menus( [
        'primary'  => __( 'Primair menu',       'aeriecura' ),
        'footer-1' => __( 'Footer — Producten', 'aeriecura' ),
        'footer-2' => __( 'Footer — Bedrijf',   'aeriecura' ),
        'footer-3' => __( 'Footer — Webshops',  'aeriecura' ),
        'footer-4' => __( 'Footer — Beheer',    'aeriecura' ),
    ] );
} );
