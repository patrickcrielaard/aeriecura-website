<?php
/**
 * ACF veldgroepen voor AerieCura.
 *
 * Bewust in PHP gedefinieerd (i.p.v. via de UI) zodat alles in versiebeheer staat.
 * Pas aan + commit i.p.v. via WP-admin te kliken.
 *
 * Vereist: Advanced Custom Fields PRO 6.0+.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'acf/init', function () {
    if ( ! function_exists( 'acf_add_local_field_group' ) ) {
        return;
    }

    /* -----------------------------------------------------------------
     * 1. Productcategorie meta
     * -------------------------------------------------------------- */
    acf_add_local_field_group( [
        'key'      => 'group_cat',
        'title'    => 'Productcategorie',
        'fields'   => [
            [
                'key'     => 'field_cat_icon',
                'label'   => 'Icoon',
                'name'    => 'icon',
                'type'    => 'select',
                'choices' => [
                    'heart-pulse' => 'Heart pulse (bloeddruk)',
                    'thermometer' => 'Thermometer',
                    'wind'        => 'Wind (saturatie)',
                    'activity'    => 'Activity (ECG)',
                    'scale'       => 'Scale (weegschaal)',
                    'package'     => 'Package',
                    'shield-check'=> 'Shield-check',
                ],
            ],
            [
                'key'       => 'field_cat_short_desc',
                'label'     => 'Korte beschrijving',
                'name'      => 'short_desc',
                'type'      => 'text',
                'maxlength' => 120,
                'instructions' => 'Maximaal ca. 90 tekens — wordt in productcategorie-tegels gebruikt.',
            ],
            [
                'key'   => 'field_cat_count',
                'label' => 'Aantal artikelen',
                'name'  => 'item_count',
                'type'  => 'number',
            ],
            [
                'key'        => 'field_cat_brands',
                'label'      => 'Hoofdmerken',
                'name'       => 'brands',
                'type'       => 'repeater',
                'sub_fields' => [
                    [ 'key' => 'field_brand_name', 'label' => 'Naam', 'name' => 'name', 'type' => 'text' ],
                    [ 'key' => 'field_brand_logo', 'label' => 'Logo', 'name' => 'logo', 'type' => 'image', 'return_format' => 'array' ],
                ],
            ],
            [
                'key'        => 'field_cat_skus',
                'label'      => "Voorbeeld-SKU's",
                'name'       => 'sample_skus',
                'type'       => 'repeater',
                'sub_fields' => [
                    [ 'key' => 'field_sku_name',  'label' => 'Naam',        'name' => 'name',        'type' => 'text' ],
                    [ 'key' => 'field_sku_num',   'label' => 'Artikelnr.',  'name' => 'article_num', 'type' => 'text' ],
                    [ 'key' => 'field_sku_class', 'label' => 'MDR klasse',  'name' => 'mdr_class',   'type' => 'select',
                      'choices' => [ 'I' => 'Klasse I', 'IIa' => 'Klasse IIa', 'IIb' => 'Klasse IIb', 'III' => 'Klasse III' ] ],
                ],
            ],
        ],
        'location' => [
            [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'productcategorie' ] ],
        ],
    ] );

    /* -----------------------------------------------------------------
     * 2. Homepage instellingen
     * -------------------------------------------------------------- */
    acf_add_local_field_group( [
        'key'    => 'group_home',
        'title'  => 'Homepage',
        'fields' => [
            [
                'key'           => 'field_hero_variant',
                'label'         => 'Hero variant',
                'name'          => 'hero_variant',
                'type'          => 'radio',
                'choices'       => [ 'a' => 'A — Split', 'b' => 'B — Editorial', 'c' => 'C — Donker' ],
                'default_value' => 'a',
                'layout'        => 'horizontal',
            ],
            [ 'key' => 'field_hero_eyebrow', 'label' => 'Hero eyebrow', 'name' => 'hero_eyebrow', 'type' => 'text' ],
            [ 'key' => 'field_hero_title',   'label' => 'Hero titel',   'name' => 'hero_title',   'type' => 'text' ],
            [ 'key' => 'field_hero_lead',    'label' => 'Hero tekst',   'name' => 'hero_lead',    'type' => 'textarea', 'rows' => 4 ],
            [
                'key'     => 'field_cat_layout',
                'label'   => 'Productcategorie layout',
                'name'    => 'cat_layout',
                'type'    => 'radio',
                'choices' => [ 'compact' => 'Compact icoon-rooster', 'detailed' => 'Detail kaarten', 'featured' => 'Featured + zijbalk' ],
                'default_value' => 'compact',
                'layout'        => 'horizontal',
            ],
        ],
        'location' => [
            [ [ 'param' => 'page_type', 'operator' => '==', 'value' => 'front_page' ] ],
        ],
    ] );

    /* -----------------------------------------------------------------
     * 3. Site Options (footer + contact + certs)
     * -------------------------------------------------------------- */
    acf_add_local_field_group( [
        'key'    => 'group_options',
        'title'  => 'AerieCura — site instellingen',
        'fields' => [
            [ 'key' => 'field_phone', 'label' => 'Telefoonnummer', 'name' => 'phone', 'type' => 'text' ],
            [ 'key' => 'field_email', 'label' => 'E-mailadres',    'name' => 'email', 'type' => 'email' ],
            [ 'key' => 'field_addr1', 'label' => 'Adres regel 1',  'name' => 'address_line1', 'type' => 'text' ],
            [ 'key' => 'field_addr2', 'label' => 'Adres regel 2',  'name' => 'address_line2', 'type' => 'text' ],
            [ 'key' => 'field_kvk',   'label' => 'KvK',            'name' => 'kvk',   'type' => 'text' ],
            [ 'key' => 'field_btw',   'label' => 'BTW',            'name' => 'btw',   'type' => 'text' ],
            [
                'key'        => 'field_certs',
                'label'      => 'Certificeringen',
                'name'       => 'certifications',
                'type'       => 'repeater',
                'sub_fields' => [
                    [ 'key' => 'field_cert_label', 'label' => 'Label', 'name' => 'label', 'type' => 'text' ],
                ],
            ],
            [
                'key'        => 'field_suppliers',
                'label'      => "Leveranciers logo's",
                'name'       => 'supplier_logos',
                'type'       => 'repeater',
                'sub_fields' => [
                    [ 'key' => 'field_sup_name', 'label' => 'Naam',  'name' => 'name',  'type' => 'text' ],
                    [ 'key' => 'field_sup_img',  'label' => 'Logo',  'name' => 'image', 'type' => 'image', 'return_format' => 'array' ],
                ],
            ],
            [
                'key'        => 'field_webshops',
                'label'      => 'Webshops',
                'name'       => 'webshops',
                'type'       => 'repeater',
                'sub_fields' => [
                    [ 'key' => 'field_shop_name', 'label' => 'Naam', 'name' => 'name', 'type' => 'text' ],
                    [ 'key' => 'field_shop_url',  'label' => 'URL',  'name' => 'url',  'type' => 'url' ],
                ],
            ],
        ],
        'location' => [
            [ [ 'param' => 'options_page', 'operator' => '==', 'value' => 'aeriecura-options' ] ],
        ],
    ] );
} );
