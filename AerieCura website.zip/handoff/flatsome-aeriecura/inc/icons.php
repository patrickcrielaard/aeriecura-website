<?php
/**
 * Inline SVG icon helper.
 *
 * Usage:
 *   aeriecura_icon( 'heart-pulse', 24 );
 *
 * Icons leven als losse .svg files in /assets/icons/. Inline rendering geeft
 * sterkte (currentColor, geen extra HTTP request).
 */

defined( 'ABSPATH' ) || exit;

function aeriecura_icon( string $name, int $size = 20 ) : string {
    $path = AERIECURA_PATH . '/assets/icons/' . $name . '.svg';
    if ( ! file_exists( $path ) ) {
        return '';
    }
    $svg = file_get_contents( $path );
    // Inject width/height
    $svg = preg_replace(
        '/<svg([^>]*)>/',
        '<svg$1 width="' . (int) $size . '" height="' . (int) $size . '">',
        $svg,
        1
    );
    echo $svg;
    return '';
}
