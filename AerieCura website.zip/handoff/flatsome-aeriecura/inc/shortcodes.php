<?php
/**
 * Herbruikbare shortcodes voor de UX Builder.
 *
 *   [aeriecura_hero variant="a"]
 *   [aeriecura_categories layout="compact"]
 *   [aeriecura_trust_strip]
 *   [aeriecura_cta_band]
 *   [aeriecura_certs]
 *
 * Elke shortcode rendert een template-part uit /parts/.
 */

defined( 'ABSPATH' ) || exit;

add_shortcode( 'aeriecura_hero', function ( $atts ) {
    $atts = shortcode_atts( [ 'variant' => 'a' ], $atts );
    ob_start();
    set_query_var( 'aeriecura_hero_variant', $atts['variant'] );
    get_template_part( 'parts/hero', $atts['variant'] );
    return ob_get_clean();
} );

add_shortcode( 'aeriecura_categories', function ( $atts ) {
    $atts = shortcode_atts( [ 'layout' => 'compact' ], $atts );
    ob_start();
    set_query_var( 'aeriecura_cat_layout', $atts['layout'] );
    get_template_part( 'parts/category-grid', $atts['layout'] );
    return ob_get_clean();
} );

add_shortcode( 'aeriecura_trust_strip', function () {
    ob_start();
    get_template_part( 'parts/trust-strip' );
    return ob_get_clean();
} );

add_shortcode( 'aeriecura_cta_band', function () {
    ob_start();
    get_template_part( 'parts/cta-band' );
    return ob_get_clean();
} );

add_shortcode( 'aeriecura_certs', function () {
    ob_start();
    get_template_part( 'parts/certs' );
    return ob_get_clean();
} );
